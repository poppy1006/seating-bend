const keyNames = {
    refreshToken: 'refreshToken',
    seatingAvailabilityTimes: 'seatingAvailabilityTimes',
    seatingInfo: 'seatingInfo',
    examOpenCourses: 'exam:open:courses',
    coursesProgram: 'exam:program:courses', // `${keyNames.coursesProgram}:${programId}:${semester}`
};

export default keyNames;
